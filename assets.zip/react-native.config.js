module.exports = {
  project: {
    ios: {},
    android: {},
  },
  assets: ["./assets/", "./assets/fonts/", "./assets/images/"],
};
