import React, {useState} from 'react'

import {View, StyleSheet, Image, Text, TouchableOpacity, SafeAreaView, Alert} from 'react-native'

import * as ImagePicker from 'expo-image-picker'

import {firebase} from './firebase'

const UploadScreen = () => {

    return(

        <SafeAreaView>

          // view will go here

        </SafeAreaView>

    )

}

export default UploadScreen;

